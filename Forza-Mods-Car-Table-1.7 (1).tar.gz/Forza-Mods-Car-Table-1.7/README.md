<h1 align="center">Forza Mods Car Table</h1>

A small tool written in c# to simplify the cheat engine cars script

<h2 align="center">Requirements</h2>

Honestly I have no idea. Its just .NET 7 so whatever that needs I guess.

People were having issues with .NET Runtime, here is the installer: [Link](https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-7.0.9-windows-x64-installer)

<h2 align="center">Usage</h2>

1. Download from github or build yourself.

2. Go into car collection ingame

3. Hover over the FD Viper

4. Click scan

5. Paste Id

6. Click swap

<h2 align="center">Screenshots</h2>

![Screenshot](/Images/Screenshot.png)

<h2 align="center">Disclaimer</h2>

The Forza Mods Car Table is a third-party modification and is not affiliated with or endorsed by the developers or publishers of Forza games.

Modding games carries inherent risks, and the usage of this "mod menu" is at your own responsibility.

Ensure that you comply with the game's terms of service and only use mods in single-player or modding-friendly environments.

The developers of the Forza Mods Car Table are not liable for any damages or consequences that may arise.
